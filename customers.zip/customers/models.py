from django.db import models

# Create your models here.
# Untuk saat ini kosong, karena kita pakai models dari app lain